---
name: tokenhub-vision
description: 调用腾讯云 TokenHub（元宝/腾讯混元）大模型 API 做图片识别（识图）与图片生成（生图）。当 Codex 无法识别、看不清或无法解析用户提供的图片内容，或用户要求用元宝/腾讯混元/TokenHub 识图、描述图片、分析图片、生成或修改图片时使用。
---

# TokenHub 识图生图

## 概述

通过腾讯云 TokenHub（元宝背后的腾讯混元大模型）提供两种能力：

- 识图：多模态图片理解，默认模型 `youtu-vita`（YT-VITA，支持一次多张图片）。
- 生图：文生图 / 参考图生图，默认 `hy-image-v3`（Hy-Image-3.0），`--lite` 可切换 `hy-image-lite` 快速模型。

API Key 已内置在 `scripts/tokenhub_image.py` 中，可用环境变量 `TOKENHUB_API_KEY` 覆盖。调用需要联网；若沙箱拦截网络，向用户说明并请求批准。

如生图报错 401007（无免费额度且未开通后付费），提示用户前往 TokenHub 控制台"在线推理服务"页面开通后付费或领取免费额度：https://console.cloud.tencent.com/tokenhub/inference

## 识图

当无法识别用户图片时，运行：

```powershell
python scripts/tokenhub_image.py understand <图片路径或URL> [更多图片] --prompt "请详细描述这张图片的内容"
```

本地图片自动转 base64；远程 URL 直接传入。单图场景可指定 `--model hy-vision-2.0-instruct`。

## 生图

```powershell
python scripts/tokenhub_image.py generate --prompt "一只橘猫坐在窗台上" --out 猫.png
python scripts/tokenhub_image.py generate --prompt "把背景改成星空" --image 参考图.png --out 修改.png
```

参考图生图用 `--image`；尺寸用 `--size 1024:1024`；不传 `--out` 时打印图片 URL（或保存到当前目录）。

## 查看可用模型

接口有调整时先用此命令核对模型 ID：

```powershell
python scripts/tokenhub_image.py models
```

## 接口要点

- Base URL：`https://tokenhub.tencentmaas.com/v1`（新加坡区域为 `https://tokenhub-intl.tencentmaas.com`）
- 鉴权：`Authorization: Bearer <API_KEY>`
- 识图：POST `/chat/completions`，`content` 为 `image_url` + `text` 数组
- 生图：POST `/images/generations`（备选 `/wand/hunyuan-image/v3-generation`）
- 识图模型：`youtu-vita`（多图）、`hy-vision-2.0-instruct`（单图）、`hunyuan-t1-vision-20250916`（单图）
- 生图模型：`hy-image-v3`（在线）、`hy-image-v3.0` / `hy-image-lite`（即将下线）

注意：脚本内置了 API Key（明文），不要把该 skill 目录分享给他人；如泄露请在 TokenHub 控制台轮换密钥。

## 常见问题

- 识图偶发 HTTP 504（上游超时）：直接重试即可，换用 hy-vision-2.0-instruct 也可降低超时概率。
- 生图报 401007：免费额度已用完或未开通，提示用户去控制台开通后付费（见上文）。
