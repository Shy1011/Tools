#!/usr/bin/env python3
"""TokenHub（腾讯混元/元宝）识图与生图工具。

子命令：
  models      列出可用模型（GET /v1/models）
  understand  识图：分析一张或多张图片并回答
  generate    生图：文生图或参考图（图生图）

API Key 默认内置，可用环境变量 TOKENHUB_API_KEY 覆盖。
"""

import argparse
import base64
import json
import mimetypes
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

DEFAULT_API_KEY = "sk-Z2HGcAKDi9mNg5laPfwh4cfQED40b3YHnnXIZHLf3ky1PP2b"
DEFAULT_BASE_URL = "https://tokenhub.tencentmaas.com/v1"

DEFAULT_VISION_MODEL = "youtu-vita"  # YT-VITA：支持一次多张图片

GEN_ENDPOINTS = ["/images/generations", "/wand/hunyuan-image/v3-generation"]
GEN_MODEL_FALLBACKS = ["hy-image-v3", "hy-image-v3.0", "HY-Image-V3.0"]
LITE_GEN_MODELS = ["hy-image-lite", "HY-Image-Lite"]

MIME_MAP = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
    ".gif": "image/gif",
    ".bmp": "image/bmp",
}


def api_key():
    return os.environ.get("TOKENHUB_API_KEY", DEFAULT_API_KEY).strip()


def base_url():
    return os.environ.get("TOKENHUB_BASE_URL", DEFAULT_BASE_URL).rstrip("/")


def mime_for(path):
    ext = Path(path).suffix.lower()
    if ext in MIME_MAP:
        return MIME_MAP[ext]
    return mimetypes.guess_type(path)[0] or "application/octet-stream"


def image_payload(value):
    """本地图片转 base64 data URI，URL 原样返回。"""
    if value.startswith(("http://", "https://", "data:")):
        return value
    p = Path(value)
    if not p.is_file():
        raise FileNotFoundError(f"图片文件不存在: {p}")
    b64 = base64.b64encode(p.read_bytes()).decode("ascii")
    return f"data:{mime_for(value)};base64,{b64}"


def request(method, path, payload=None, timeout=180):
    url = base_url() + path
    headers = {
        "Authorization": f"Bearer {api_key()}",
        "Content-Type": "application/json",
    }
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        raise RuntimeError(f"HTTP {e.code} {url} -> {body[:1200]}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"网络错误 {url} -> {e.reason}") from e


def cmd_models(_args):
    data = request("GET", "/models")
    items = data.get("data") or []
    if not items:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return
    for m in sorted(items, key=lambda x: str(x.get("id", ""))):
        print(f"{m.get('id')}\t{m.get('status', '')}\t{m.get('name', '')}")


def cmd_understand(args):
    content = []
    for img in args.images:
        content.append({"type": "image_url", "image_url": {"url": image_payload(img)}})
    content.append({"type": "text", "text": args.prompt})
    payload = {
        "model": args.model,
        "messages": [{"role": "user", "content": content}],
        "stream": False,
    }
    if args.max_tokens:
        payload["max_tokens"] = args.max_tokens
    resp = request("POST", "/chat/completions", payload, timeout=args.timeout)
    try:
        print(resp["choices"][0]["message"]["content"])
    except (KeyError, IndexError) as e:
        raise RuntimeError(
            f"响应格式异常: {json.dumps(resp, ensure_ascii=False)[:1000]}"
        ) from e


def extract_image(resp):
    """在响应 JSON 中递归查找图片 URL 或 base64 数据。"""
    if not isinstance(resp, dict):
        return None

    def find(obj, depth=0):
        if depth > 8 or obj is None:
            return None
        if isinstance(obj, dict):
            for key in ("b64_json", "image_base64", "image"):
                val = obj.get(key)
                if isinstance(val, str) and val:
                    return ("b64", val)
            url = obj.get("url")
            if isinstance(url, str) and url.startswith("http"):
                return ("url", url)
            for val in obj.values():
                found = find(val, depth + 1)
                if found:
                    return found
        elif isinstance(obj, list):
            for val in obj:
                found = find(val, depth + 1)
                if found:
                    return found
        return None

    return find(resp)


def save_image(kind, value, out):
    if kind == "b64":
        if value.startswith("data:"):
            value = value.split(",", 1)[1]
        data = base64.b64decode(value)
        if out:
            dest = Path(out)
        else:
            dest = Path(f"tokenhub-image-{int(time.time())}.png")
        dest.write_bytes(data)
    else:
        if out:
            dest = Path(out)
        else:
            dest = Path(f"tokenhub-image-{int(time.time())}.png")
        req = urllib.request.Request(value, headers={"User-Agent": "codex-tokenhub-vision"})
        try:
            with urllib.request.urlopen(req, timeout=180) as r, open(dest, "wb") as f:
                f.write(r.read())
        except urllib.error.URLError as e:
            raise RuntimeError(f"下载生成图片失败: {e.reason}") from e
    return str(dest.resolve())


def cmd_generate(args):
    body = {
        "model": "placeholder",
        "prompt": args.prompt,
        "size": args.size,
    }
    if args.image:
        body["images"] = [image_payload(args.image)]
    if args.seed is not None:
        body["seed"] = args.seed
    if args.revise is not None:
        body["revise"] = args.revise

    if args.model:
        models = [args.model]
    elif args.lite:
        models = LITE_GEN_MODELS
    else:
        models = GEN_MODEL_FALLBACKS

    last_err = None
    for model in models:
        for endpoint in GEN_ENDPOINTS:
            body["model"] = model
            try:
                resp = request("POST", endpoint, body, timeout=args.timeout)
            except Exception as e:  # noqa: BLE001 - 逐个组合重试
                last_err = e
                continue
            if isinstance(resp, dict) and resp.get("job_id"):
                print(json.dumps(resp, ensure_ascii=False, indent=2))
                print("任务已异步提交，请用返回的 job_id 轮询结果。")
                return
            found = extract_image(resp)
            if found:
                path = save_image(found[0], found[1], args.out)
                print(f"model={model} endpoint={endpoint}")
                print(path if args.out else found[1])
                return
            last_err = RuntimeError(
                f"响应中没有图片: {json.dumps(resp, ensure_ascii=False)[:800]}"
            )
    raise last_err or RuntimeError("生图失败")


def main():
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_models = sub.add_parser("models", help="列出可用模型")
    p_models.set_defaults(func=cmd_models)

    p_understand = sub.add_parser("understand", help="识图：分析一张或多张图片")
    p_understand.add_argument("images", nargs="+", help="图片路径或 URL")
    p_understand.add_argument(
        "--prompt", default="请详细描述这张图片的内容。", help="理解指令"
    )
    p_understand.add_argument(
        "--model",
        default=DEFAULT_VISION_MODEL,
        help=f"视觉模型（默认 {DEFAULT_VISION_MODEL}，支持多图）",
    )
    p_understand.add_argument("--max-tokens", type=int, default=None)
    p_understand.add_argument("--timeout", type=int, default=180)
    p_understand.set_defaults(func=cmd_understand)

    p_generate = sub.add_parser("generate", help="生图：文生图或参考图生图")
    p_generate.add_argument("--prompt", required=True, help="生图提示词")
    p_generate.add_argument(
        "--model", default=None, help="生图模型（默认自动尝试 hy-image-v3 系列）"
    )
    p_generate.add_argument("--lite", action="store_true", help="使用 HY-Image-Lite 快速模型")
    p_generate.add_argument("--size", default="1024:1024", help="尺寸，如 1024:1024")
    p_generate.add_argument("--image", default=None, help="参考图路径或 URL（图生图）")
    p_generate.add_argument("--seed", type=int, default=None)
    p_generate.add_argument("--revise", type=int, default=None)
    p_generate.add_argument("--out", default=None, help="保存图片的路径")
    p_generate.add_argument("--timeout", type=int, default=240)
    p_generate.set_defaults(func=cmd_generate)

    args = parser.parse_args()
    try:
        args.func(args)
    except FileNotFoundError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        sys.exit(2)
    except RuntimeError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
